package com.airline;

/**
 * JAR dosyası için Launcher sınıfı.
 * JavaFX uygulamalarında executable JAR oluşturmak için gereklidir.
 */
public class Launcher {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
